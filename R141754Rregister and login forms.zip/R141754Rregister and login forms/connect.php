<?php
$vet_conn=new mysqli('localhost','vethosipal_user','test','vethospital_db');
  if($vet_conn->connect_errno){
	  
	  echo "Error".$vet_conn->connect_errno." has occured";
	  
  }else{
	  
	
  }
	
?>


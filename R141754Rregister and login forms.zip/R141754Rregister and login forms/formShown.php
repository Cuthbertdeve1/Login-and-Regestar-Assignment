
<?php
 include_once('connect.php');
 $sName =$_POST["username"];
 $password =$_POST["Password"];
$email =$_POST["Email"];
$phone =$_POST["phone"];

	
	$query_string="
 INSERT INTO register
 Values ('$sName','$password','$email','$phone')
   ";

   if($vet_conn->query($query_string)){
	   
	   echo "Data inserted successfully";
   }
   $_SESSION['welcome'] = $index;
 header("Location: main_page/index.php")
	  ?>
	
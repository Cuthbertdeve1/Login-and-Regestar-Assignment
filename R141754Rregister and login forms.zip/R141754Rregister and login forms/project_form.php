<!DOCTYPE html>
<html>
<head>
<title>vet form</title>
<link rel="stylesheet" href="formCss.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.css">


</head>
<body>
	<div id="myform">
	<div id="header">
	<h1> Vertinary form Registration</h1>
	<p>if you have no account sign in</p>
	</div>
	<form action="formShown.php" method="post" enctype="multipart/form-data" id="">
		<fieldset><br>
			<legend>Sign In Form</legend>
		<fieldset>
			<legend>User Name</legend>
			<input type="text" id="form_username" name="username"required ><span id="username_error_message" required></span>
			<legend>Password</legend>
			<input type="password" id="form_password" name="Password" required ><span id="password_error_message"></span>
			<legend>Password Retype</legend>
			<input type="password" id="form_retry_password" name="retype_Password" ><span id="retype_password_error_message" required></span>
			<legend>Email</legend>
			<input type="email" id="form_email" name="Email" ><span id="email_error_message"></span>
			<legend>Phone</legend>
			<input type="tel" id="form_phone" name="phone" >
			
		</fieldset><br>
		
			<input type="reset" name="Reset" id="Reset" value="reset">
			<input type="submit" id="submit" name="submit" value="singIn">
		</fieldset>
		</form>
	</div><br><br>


</body>
<script src="jquery-2.2.0.js"></script>
<script src="project_form.js"></script>
</html>
<!DOCTYPE html>
<html class="no-js" lang="en"><head>
<meta content="text/html; charset=UTF-8">

<link href="codes%20css,jqury,html_files/coderwall-f02890480263e416e9a02de05b89f117.css" media="screen" rel="stylesheet" type="text/css">
<script src="project_form.js"></script>


</head>
<body class="protip-single"><header id="masthead"><div class="inside-masthead cf">
<header style="text-align:center;color:white;background-color:#202020;margin-top:5px;">
<h1>Mt Vetinary Hospital</h1>
</header>
<nav id="nav"><ul><li><a href="formlogin.php">Login </a></li><li><a href="project_form.php">Register</a></li></ul></nav></div></header>
<div id="x-active-preview-pane">

<div class="inside cf x-protip-pane" >

<div class="cf fullpage protip-single tip-container x-protip-content" id="x-protip">
<aside class="tip-sidebar">

<div class="side-btm">
<h1>LOGIN</h1>
<h3><form action="formlogin.php" method="post">


<legend>UserName</legend>
<input type="text" name="username" id="file_username"><br>
<legend>Password</legend>
 <input type="password" name="password" id="file_password"><br><br>
<input type="submit" name="s" value="login" style="color:black;text-align:left;">

		</form>
		 
</h3>
</div>
</aside>
<article class="tip-panel" id="vsdrug">


<header class="tip-header"><div  class="add-comment cf" id="add">
<h1 class="tip-title" itemprop="headline">
The nerest doctor to your animal register and be party of us
</h1>

<form action="formShown.php" method="post" enctype="multipart/form-data" id="">
		<fieldset><br>
			<legend>Sign In Form</legend>
		<fieldset>
			<legend>User Name</legend>
			<input type="text" id="form_username" name="username"required ><span id="username_error_message" required></span>
			<legend>Password</legend>
			<input type="password" id="form_password" name="Password" required ><span id="password_error_message"></span>
			<legend>Password Retype</legend>
			<input type="password" id="form_retry_password" name="retype_Password" ><span id="retype_password_error_message" required></span>
			<legend>Email</legend>
			<input type="email" id="form_email" name="Email" ><span id="email_error_message"></span>
			<legend>Phone</legend>
			<input type="tel" id="form_phone" name="phone" >
			
		</fieldset><br>
		
			<input type="reset" name="Reset" id="Reset" value="reset">
			<input type="submit" id="submit" name="submit" value="singIn">
		</fieldset>
		</form>
	</div><br><br>
</header>


</article>
<section class="comments"><div class="add-comment cf" id="add-comment">
<h2>
<i class="fa fa-comment"></i>
Add a comment
</h2>
<form accept-charset="UTF-8" action="/p/vsdrug/comments" class="new_comment" id="new_comment" method="post">
<div style="margin:0;padding:0;display:inline">
<textarea cols="40" id="comment_comment" label="false" name="comment[comment]" rows="5"></textarea>
<input class="button" value="Submit comment" type="submit">
</form>

</div>
</section>
<div class="mobile-job">


</div>
</div>
</div>


</div>
 </body>
 </html
    
